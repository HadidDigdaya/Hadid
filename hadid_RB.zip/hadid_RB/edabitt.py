def pararel(list):
    r_total=0
    for r in list:
        r_total=r_total + 1/r
    return 1/r_total

print(pararel([100,200,47]))

