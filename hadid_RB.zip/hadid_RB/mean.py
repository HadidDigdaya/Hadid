def mean(list):
    total = 0
    jumlah = 0
    for i in (list):
        total = total + i
        jumlah = jumlah + 1
    return total/jumlah

print(mean([2,3,4,5,10,12]))
