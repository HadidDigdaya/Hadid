def relation(name):
    dict= {"darth father":"father",
           "mela":"sister",
           "hadid":"brother in law",
           "R202":"droid"}
    return "luke,I am your "+dict[name]

print(relation("darth father"))
print(relation("mela"))
print(relation("hadid"))
print(relation("R202"))

