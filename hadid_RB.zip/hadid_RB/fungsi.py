#kategori bmi
def bmi(berat,tinggi):
    bmi=berat/(tinggi*tinggi)
    if(bmi<=18.5):
        print("kurang")
    elif(bmi>18.5 and bmi<23):
        print("ideal")
    elif(bmi>=23 and bmi<30):
        print("berlebih")
    else:
        print("obesitas")

def pola_makan(tipe_bmi):
    if(tipe_bmi == "kurang"):
        print("makan 5x sehari")
    elif(tipe_bmi == "ideal"):
        print("makan 2x sehari")
    elif(tipe_bmi =="obesitas"):
        print("puasa seminggu")

bmi_saya =bmi(21,213)


pola_makan(bmi_saya)