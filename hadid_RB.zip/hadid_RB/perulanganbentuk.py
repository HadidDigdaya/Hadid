def cetak():
    for hadid in range(15):
        for digda in range(15-hadid): 
                  print(" ",end=" ")
        for digda in range(hadid):
                 print("*", end="")
        print()

cetak()


def cetak():
    for rehan in range(15):
        for syahfa in range(rehan):
           print("* ", end="")
        print()



