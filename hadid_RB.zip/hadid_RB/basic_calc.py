def pertambahan(x,y):
    return x + y

def perkalian(x,y):
    return x * y

def pembagian(x,y):
    return x/y

pilihan=input("pilih operasi:(+,*,/)")

angka1=int(input("masukan angka pertama"))
angka2=int(input("masukan angka kedua"))


if pilihan == "+":
    print (f"hasil dari{angka1} + {angka2} = {tambah(angka1,angka2)}")
elif pilihan == "*":
    print (f"hasil dari {angka1} * {angka2} = {perkalian(angka1,angka2)}")
elif pilihan =="/":
    print (f"hasil dari {angka1} / {angka2} = {pembagian(angka1,angka2)}")






