# operator pemberian nilai
bilangan=7

#operator  perbandingan
bilangan==8
bilangan>=10
bilangan<=9
bilangan!=7
