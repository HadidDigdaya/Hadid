def urutkan_list(angka_list):
            n = len(angka_list)
            for i in range (n): 
                for j in range(0, n-i-1):
                    if angka_list[j] > angka_list[j+1]:

                            angka_list[j], angka_list[j+1] = angka_list[j+1], angka_list[j]
def hitung_median(angka_list):
            urutkan_list(angka_list)

            n = len(angka_list)
            if n % 2 == 1:
                median = angka_list[n // 2]
            else:
                median = (angka_list[n // 2 - 1] + angka_list [n // 2]) / 2
            return median

n = int(input("masukkan jumlah angka:"))
x = [0] * n
for i in range(n):
            angka = int(input(f"masukkan angka {} ")) #salah
            x[i] = angka

print(f"median dari list tersebut adalah: {hitung_median(x)}") #salah
        
