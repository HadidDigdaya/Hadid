#perubahan energi panas
def perubahan_energi_panas(m,c,t) :
#Q= besaran kalor
#m= massa zat
#c= kalor jenis zat
#t= perubahan suhu
    Q = m * c * t
    print(Q)

m = int(input("masukkan nilai m = "))
c = int(input("masukkan nilai c = "))
t = int(input("masukkan nilai t = "))

perubahan_energi_panas(m,c,t)

