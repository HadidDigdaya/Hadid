#soal no.16 konversi suhu(reamur,celcius,kelvin,farenheit)

#input/masukkan suhu dan satuan asal
def konversi_suhu(celcius,farenheit,kelvin,reamur) :
    c_ke_f = (celcius * 9/5) + 32
    c_ke_k = celcius + 273.15
    c_ke_r = 4/5 * celcius
    f_ke_c = (f - 32) * 5/9
    F_ke_k = (f - 32) * 5/9 + 273.15
    f_ke_r = (f - 32) * 4/9
    k_ke_c = k - 273.15
    k_ke_f = (k - 273.15) * 9/5 + 32
    k_ke_r = (k - 273.15) * 4/5
    r_ke_c = r * 5/4
    r_ke_f = (r * 9/4) + 32
    r_ke_k = (r * 5/4) + 273.15

#proses 
    print("celcius ke fanrenheit adalah",c_ke_f,"fanrenheit")
    print("celcius ke kalvin adalah",c_ke_k,"kelvin")
    print("celcius ke reamur adalah",c_ke_r,"reamur")
    print("fanrenheit ke celcius adalah",f_ke_c,"celcius")
    print("fanrenheit ke kelvin adalah",F_ke_k,"kelvin")
    print("fanrenheit ke reamur adalah",f_ke_r,"reamur")
    print("kelvin ke celcius adalah",k_ke_c,"celcius")
    print("kelvin ke fanrenheit adalah",k_ke_f,"fanrenheit")
    print("kelvin ke reamur adalah",k_ke_r,"reamur")
    print("reamur ke celcius adalah",r_ke_c,"celcius")
    print("reamur ke fanrenheit adalah",r_ke_f,"fanrenheit")
    print("reamur ke kelvin adalah",r_ke_k,"kelvin")

#output
if konversi_suhu :
            c = float(input("masukkan celcius = "))
            f = float(input("masukkan fanrenheit = "))
            k = float(input("masukkan kelvin = "))
            r = float(input("masukkan reamur = "))
            konversi_suhu(c,f,k,r)