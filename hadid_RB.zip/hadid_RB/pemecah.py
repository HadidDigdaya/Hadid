def pemecah_angka(num):
    x = num // 2 #// pembagian bulat jika bilangan mempunya koma(,) makan akan dibulatkan
    y = num - x
    return [x,y]
n = 11
hasil = pemecah_angka(n)
print(f"angka yang membentuk adalah {hasil}")
