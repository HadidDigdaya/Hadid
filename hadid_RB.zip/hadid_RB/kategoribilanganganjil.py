def kategori_bilangan(angka):
    if(angka % 2==0):
       print("genap")
    else:
        print("ganjil")
    
kategori_bilangan(7)


def kategori_kelipatan_tujuh(angka):
    if(angka % 7==0):
       print("kelipatan 7")
    else:
        print("bukan kelipatan 7")
kategori_kelipatan_tujuh(8)
kategori_kelipatan_tujuh(49)
kategori_kelipatan_tujuh(114)

