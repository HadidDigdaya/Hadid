


















#1. Cabang 3
nilai=int(input('masukan nilai:'))

if nilai>=90:
   print('predikat A')
elif nilai>=80:
   print('predikat B')
elif nilai>=60:
   print('predikat C')
else:
    print('predikat D')

#2. Cabang 4
nilai=int()










#3. if banyak













#4. if bertingkat
nilai=int(input('masukan nilai:'))
usia=int(input('masukan usia:'))

if nilai>=75:
   if(usia<15):
      print('selamat adek,kamu lulus')
   else:
      print('selamat kakak, kamu lulus')
else:
    if(usia<15):
      print('mohon maaf dek,coba lagi ya')
    else:
      print('mohon maaf kakak,coba lagi ya')
