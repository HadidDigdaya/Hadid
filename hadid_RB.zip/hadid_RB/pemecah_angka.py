def pemecahAngka(num):
    # if num % 2==0:
        # return "angka harus ganjil"
    
        i=num // 2
        j=num - i
        return (i,j)

n = 11
hasil = pemecahAngka (n)
print(f"angka yang membentuk adalah {hasil}")



