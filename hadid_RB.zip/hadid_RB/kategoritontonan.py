def kategori_tontonan(umur):
    if(umur>=18):
     print("dewasa")
    elif(umur >= 13 and umur < 18):
     print("remaja")
    elif(umur >=7 and umur <13):
     print("anak-anak")
    elif(umur>2):
     print("semua umur")
    else:
     print("tidak boleh menonton")
kategori_tontonan(67)



