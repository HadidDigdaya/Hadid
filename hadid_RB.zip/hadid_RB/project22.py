def penyelesaian_linear():   #jika bilangan 0 maka
            print("masukan koefisien untuk 2 persamaan linear dalam bentuk ax + by + c = 0")
            
            a1= float(input("persamaan 1 - masukan a1: "))
            b1= float(input("persamaan 1 - masukan b1: ")) 
            c1= float(input("persamaan 1 - masukan c1: ")) 
            
            a2= float(input("persamaan 2 - Masukan a2: "))
            b2= float(input("persamaan 2 - Masukan b2: ")) 
            c2= float(input("persamaan 2 - Masukan c2: "))

            c1 = -c1
            c2 = -c2

            faktor = (b2 * a1) - (b1 * a2) 

            if faktor != 0:
                x_numerator = (c1 * a2 - c2 * a1)
                x = x_numerator / faktor

                y_numerator = (c1 - a1 * x)
                y = y_numerator / b1

                print("nilai x:", x)
                print("nilai y:", y)
            else:
                if (c1 * a2 - c2 * a1)== 0:
                    print("Persamaan memiliki banyak solusi (sistem saling bergantung).")
                else:
                    print("persamaan tidak memiliki solusi (sistem bertentangan).")
penyelesaian_linear()