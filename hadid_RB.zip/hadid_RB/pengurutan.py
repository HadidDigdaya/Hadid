def pengurutan(num):
    for x in range(len(num)):
        for i in range(len(num)-1):
            if(num[i]> num [i+1]):
                k = num[i]
                num [i] = num [i + 1]
                num [i + 1] = k
    print(num)
pengurutan([12,3,1,7])