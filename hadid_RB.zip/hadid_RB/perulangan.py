def perulangan():
   for hadid in range(100):
      print(hadid+1)

#perulangan()
def bilangan_ganjil():
    for hadid in range(100):
        if(hadid % 2 ==1):
           print(hadid+1)

bilangan_ganjil()
