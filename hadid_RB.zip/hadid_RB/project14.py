# Menghitung Daya
def hitung_daya(w, t):
    """
    Fungsi untuk menghitung daya (P).
    P = w / t
    w: usaha (dalam joule)
    t: waktu (dalam detik)
    """
    if t == 0:
        return "Waktu tidak boleh nol"
    return w / t

# Menghitung Energi Kinetik
def hitung_energi_kinetik(m, v):
#Fungsi untuk menghitung energi kinetik (Ek).
# Ek = 0.5 * m * v^2
# m: massa (dalam kilogram)
# v: kecepatan (dalam meter per detik)

    return 0.5 * m * v ** 2

# Input dari pengguna
usaha = float(input("Masukkan usaha (dalam joule): "))
waktu = float(input("Masukkan waktu (dalam detik): "))
massa = float(input("Masukkan massa (dalam kilogram): "))
kecepatan = float(input("Masukkan kecepatan (dalam meter per detik): "))

# Menghitung daya dan energi kinetik
daya = hitung_daya(usaha, waktu)
energi_kinetik = hitung_energi_kinetik(massa, kecepatan)

# Menampilkan hasil
print(f"Daya: {daya} watt")
print(f"Energi Kinetik: {energi_kinetik} joule")