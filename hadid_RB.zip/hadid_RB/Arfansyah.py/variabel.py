
# 1. Suatu persegi memiliki panjang sisi 7 cm. Keliling persegi tersebut adalah...


sisi = int(input("masukkan nilai sisi = "))
print (sisi * sisi)

