# perhitungan rumus volume, luas permukaan, luas selimut dan luas permukaan tanpa tutup 
# vol = phi * r ** 2 * t
# luas permukaan = 2 * phi * r (r + t)
# luas selimut tabung = 2 * phi * r * t
# luas permukaan tabung tanpa tutup = phi * r * (r + 2t)

r = int(input("masukkan jari jari tabung = "))
t = int(input("masukkan tinggi tabung = "))
vol = (22/7) * r ** 2 * t
luas_permukaan = 2 * (22/7) * r * (r + t) 
luas_selimut_tabung = 2 * (22/7) * r * t
luas_permukaan_tabung_tanpa_tutup =  (22/7) * r * (r + 2 * t)
luas_alas_dan_tutup = (22/7) * r ** 2

print("volume tabung dengan jari jari", r,"dan dengan tinggi", t, " cm adalah ", vol)
print("luas permukaan tabung dengan jari jari", r,"dan dengan tinggi", t, " cm adalah ", luas_permukaan)
print("luas selimut tabung dengan jari jari", r,"dan dengan tinggi", t, " cm adalah ", luas_selimut_tabung)
print("luas permukaan tabung tanpa tutup dengan jari jari", r,'dan dengan tinggi', t, " cm adalah ", luas_permukaan_tabung_tanpa_tutup)
print("luas alas dan tutup dengan jari jari", r," cm adalah ", luas_alas_dan_tutup)