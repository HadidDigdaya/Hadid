def get_first_value(angka):
    print(angka[0])

get_first_value(['1', '2' '3'])