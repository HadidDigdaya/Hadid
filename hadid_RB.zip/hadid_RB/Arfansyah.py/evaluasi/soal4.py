def triarea(a, t):
    jumlah = a * t / 2
    print(jumlah)

a = int(input("masukkan alas ="))
t = int(input("masukkan tinggi ="))
triarea(a, t)