def cubes(n):
    jumlah = n ** 3
    print(jumlah)

n = int(input("masukkkan n ="))
cubes(n)