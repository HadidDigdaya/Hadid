def howManySeconds(hours):
    jumlah = hours * 3600
    print(jumlah)

hours = int(input("masukkan jam ="))
howManySeconds(hours)