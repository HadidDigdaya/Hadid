def remainder(x, y):
    jumlah = x
    print(jumlah)

x = int(input("masukkan x ="))
y = int(input("masukkan y ="))
remainder(x, y)