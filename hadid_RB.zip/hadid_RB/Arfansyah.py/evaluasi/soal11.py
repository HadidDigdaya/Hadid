def nextEdge(side1, side2):
    jumlah = side1 + side2 - 1
    print(jumlah)

side1 = int(input("side 1 ="))
side2 = int(input("side 2 ="))
nextEdge(side1, side2)