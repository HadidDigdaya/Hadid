def calcage(age):
    jumlah = age * 365
    print(jumlah)

age = int(input("masukkan umurmu ="))
calcage(age)