def circuitPower(voltage, current):
    jumlah = voltage * current 
    print(jumlah)

voltage = int(input("voltage = "))
current = int (input("current = "))
circuitPower(voltage, current)