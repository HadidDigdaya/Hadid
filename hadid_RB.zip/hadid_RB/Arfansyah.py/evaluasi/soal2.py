def addition(x, y):
    jumlah = x + y
    print(jumlah)

x = int(input("masukkan nilai x ="))
y = int(input("masukkan nilai y ="))
addition(x, y)