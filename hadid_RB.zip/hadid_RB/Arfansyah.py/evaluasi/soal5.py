def addition (num):
    jumlah = num + 1
    print(jumlah)

num = int(input("masukkan num ="))
addition(num)