def convert(minute):
    jumlah = minute * 60
    print(jumlah)

minute = int(input("masukkan menit = "))
convert(minute)