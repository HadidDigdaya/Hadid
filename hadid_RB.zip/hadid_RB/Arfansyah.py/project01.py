while True:
    print("\n")
    print("[]:::::::::::::::PEMILIHAN TEMA SOAL:::::::::::::::[]")
    print("~~~~~SILAHKAN PILIH TEMA~~~~~")
    print("\n")
    print("1.PERSAMAAN LINEAR 1 VARIABEL")
    print("2.LISTRIK, MAGNET, SUMBER ENERGI RANGKAIAN RESISTOR PARALEL DAN SERI")
    print("3.GAYA COLOUMB")
    print("4.SUHU KALOR PEMUAIAN")
    print("5.PERUBAHAN ENERGI PANAS")
    print("6.TEOREMA PYTHAGORAS")
    print("7.RELASI DAN FUNGSI MENCARI BILANGAN DARI SUATU HIMPUNAN")
    print("8.USAHA ENERGI & PESAWAT SEDERHANA")
    print("9.GAYA, GERAK, USAHA ENERGI, DAN PESAWAT SEDERHANA")
    print("10.LISTRIK, MAGNET, DAN SUMBER ENERGI")
    print("11.SUHU, KALOR, PEMUAIAN KONVERSI SUHU (REAMUR, CELCIUS, KELVIN, FAHRENHEIT")
    print("12.TEOREMA PYTHAGORAS")
    print("13.ENERGI KINETIK")
    print("\n")
    pilihan = float(input("Masukkan pilihan anda = "))

    if pilihan == 1 :
        print("PERSAMAAN LINEAR 1 VARIABEL")
        def persamaan_linier1 (a,b):
              persamaan_linier = -a / b
              print(f" Hasil Persamaan linier (x) dari {a} dan {b} adalah {persamaan_linier}")

        print("PERSAMAAN LINIER SATU VARIEBEL")
        print("   RUMUS   ")
        print("   Ax + B = A - xB")
        print(" ===============================================================")
          
        a = float(input(" masukkan A ="))
        b = float(input(" masukkan B ="))
        persamaan_linier1(a, b)

        print(" 1. kembali")
        print(" 2. berhenti")
        operation = input(" Pilih = ")
   
        if operation == ("1"):
            continue
        elif operation == ("2"):
            print(" Akhir dari Program,Sekian Terimakasih")

    elif pilihan == 2 :
        print("RANGKAIAN RESISTOR PARALEL & SERI")
        def hitung_rp(resistor):
            rtotal = 0
            for R in resistor:
                rtotal += 1  / R
            rtotal = 1 / rtotal
            return rtotal
        
        def hitung_rs(resistor):
            rtotal = 0
            for R in resistor:
                rtotal += R
            return rtotal
        
        r = int(input("Masukkan jumlah resistor : "))
        resistor = [float(input("Masukkan nilai resistor ke-" + str(i+1)+" (ohm):")) for i in range(r)]

        hitung_rp(resistor)
        hitung_rs(resistor)
        rs = hitung_rs(resistor)
        rp = hitung_rp(resistor)

        print("Resistansi total untuk rangkaian pararel :", rp, "ohm")
        print("Resistansi total untuk rangkaian seri :", rs, "ohm")

        if operation == ("1"):
            continue
        elif operation == ("2"):
            print(" Akhir dari Program,Sekian Terimakasih")

    elif pilihan == 3 :
        def gaya_coulumb(q1 , q2):
               F = 9 * 10*9 * (q1 + q2) / r**2
               print(f" Hasil Gaya Coulumb dari Muatan1 {q1} dan Muatan2 {2} adalah {F}")

        print(" Gaya Coulumb")
        print(" Rumus = 9 * 10^9 * (q1 + q2) / r^2")
        q1 = float(input(" Masukkan Muatan1 = "))
        q2 = float(input(" Masukkan Muatan2 = "))
        gaya_coulumb(q1 , q2)

        print(" ==============================")
        print(" 1. kembali")
        print(" 2. berhenti")
        print(" ==============================")
        operation = input(" Pilih = ")
   
        if operation == ("1"):
            print(" Anda Kembali ke Menu")
            continue
        elif operation == ("2"):
            print(" Akhir dari program,Sekian Terimakasih")
            print("\n")
            break
    
    elif pilihan == 4 :
        print("SUHU KALOR DAN PEMUAIAN")
        m = int(input("masukkan m = "))
        v = int(input("masukkan v ="))
        Q   = 0.5 * m * v**2
        print("hasil perubahan adalah", Q)

    elif pilihan == 5:
        print("SUHU KALOR DAN PEMUAIAN")
        def perubahan(m, c, Tawal, Takhir):
            Q = (m * c * (Tawal - Takhir))
            print(Q)

        m = float(input("masukkan massa benda (gram): "))
        c = float(input("masukkan kalor jenis(j/g'C): "))
        Tawal = float(input("masukkan suhu awal(C): "))
        Takhir = float(input("masukkan suhu akhir (C): "))
        perubahan(m, c, Tawal, Takhir)


               
        

