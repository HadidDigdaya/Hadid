        pilih = float(input("Masukkan pilihan soal = "))

        if (pilih == 1):
            sudut = int(input("masukkan sudut dari c "))
            if (sudut == 90):
                print (" Sudut C ke A adalah siku siku")
                
            elif (sudut <=90) and (sudut >= 0):
                print("Sudut dari C ke A adalah lancip")
                
            elif (sudut >= 90) and (sudut <= 180):
                print("sudut dari C ke A adalah tumpul")
                
        elif (pilih == 2):
            sudut = int(input("masukkan  sudut dari c = "))
            if (sudut == 90):
                print("sudut  C ke B adalah siku siku")
            elif (sudut <= 90) and (sudut >= 0):
                print("Sudut dari C ke B adalah lancip")
            elif (sudut >= 90) and (sudut <= 180):
                print("Sudut C ke B adalah tumpul")