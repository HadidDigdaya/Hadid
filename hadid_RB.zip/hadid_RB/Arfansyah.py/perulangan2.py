for x in range(20):
    print(x+1, "aowkawkokawokwqokaokwo")

#array
pacars = ['nabila', 'della', 'safa', 'bayu']

for pacar in pacars:
    print("yudha sayang", pacar)