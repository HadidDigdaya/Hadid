print("MENCARI BILANGAN GANJIL DALAM SUATU HIMPUNAN")
input_himpunan = input("Masukkan himpunan angka (pisahkan dengan spasi): ")
himpunan = [int(x) for x in input_himpunan.split()]
print("Sebelum dicari bilangan ganjil =", himpunan)
himpunan.sort()
ganjil = [i for i in himpunan if i % 2 != 0]
print("Bilangan ganjil dalam himpunan adalah", ganjil)