

luas = int(input("masukkan nilai luas = "))
alas = int(input("masukkan nilai alas = "))

tinggi=(2 * luas)/ alas
print(tinggi)