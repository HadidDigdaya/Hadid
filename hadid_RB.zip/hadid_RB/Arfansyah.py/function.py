def tabung(r, t):
    vol = (22/7) * r ** 2 *  t
    lp = 2 * (22/7) * r * (r + t)
    lst = 2 * (22/7) * r * t
    latt = (22/7) * r ** 2

    print("volume tabung adalah", vol)
    print("luas permukaan tabung adalah", lp)
    print("luas selimut tabung adalah", lst)
    
tabung(4, 8)                                                    