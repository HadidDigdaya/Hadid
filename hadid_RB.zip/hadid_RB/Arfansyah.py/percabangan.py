# mengecek kebolehan menonton atau tidak

nilai = int(input("masukkan nilai = "))

if( nilai > 73 ):
    print("selamat anda lulus")   
elif ((nilai <= 73) and (nilai >= 50)):
    print ("kerjakan ulang")
elif (nilai < 50):
    print ("push up dulu 100 kali baru kerjakan ulang")