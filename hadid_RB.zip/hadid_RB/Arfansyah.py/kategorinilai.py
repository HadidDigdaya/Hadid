skor = int(input("masukkan nilai = "))

if(skor > 90 and skor <= 100):
    print("A")
elif(skor > 70 and skor <= 90):
    print("B")
elif(skor > 70 and skor <= 80):
    print("C")
elif(skor > 60 and skor <=70):
    print("D")
elif(skor >= 0 and skor <= 60):
    print("E")
else:
    print("maaf nilai yang anda masukkan salah")