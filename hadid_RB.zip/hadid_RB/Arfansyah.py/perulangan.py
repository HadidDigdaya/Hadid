# mencetak angka 1 sampai 5000
# perulangan
# range (1, 51) => bilangan satu sampai sebelum 51 jumlah penambahannya 1

for x in range(11, 0, -1):
    for y in range(x):
        print(" * ", end= "")

    print("")