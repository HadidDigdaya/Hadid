def kategorikan_sudut(sudut_c):
    if sudut_c < 90:
        return "segitiga tumpul"
    elif sudut_c == 90:
        return "Segitiga siku siku"
    else:
        return "segitiga lancip"

    a = float(input("masukkan panjang sisi a: "))
    b = float(input("masukkan panjang sisi b: "))
    c = a**2 + b**2

    sudut_c_rad = a / c
    sudur_c_deg = sudut_c_rad

    kategori = kategorikan_sudut(sudur_c_deg)
    print("sudut C adalah", sudur_c_deg, "derajat", kategori)