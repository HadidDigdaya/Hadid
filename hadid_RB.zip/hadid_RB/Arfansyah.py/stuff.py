def persamaanlinear1(a, b):

    if a == 0:
        print("persamaan ini tidak memiliki solusi")
    elif b == 0:
        print("persamaan ini tidak memiliki solusi")
    else:
        x = -b / a
        print("print solusi dari persamaan adalah x = ", x)
print("persamaan linear 1 variabel")
a = float(input("masukkan koefisien a = "))
b = float(input("masukkan koefisien b = "))
persamaanlinear1(a, b)