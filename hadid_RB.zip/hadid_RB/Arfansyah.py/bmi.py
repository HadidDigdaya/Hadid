# kategori berat badan
# jika berat badan di bawah 18,5 maka kategori berat badan kurang proporsional
# jika berat badan di antara 18,5 sampai dengan 22,9 maka kategori berat badan ideal
# jika berat badan di antara 23 sampai dengan 29,9 maka kategori berat badan berat badan berlebih (berpotensi obesitas)
# jika berat badan di atas 30 maka kategori berat badan obesitas

berat_badan = int(input("masukkan berat badanmu = "))
tinggi = float(input("masukkan tinggi badanmu ="))
rumus_bmi = berat_badan / (tinggi ** 2)


if (rumus_bmi <18.5):
    print("berat badan kurang proposional")
elif(rumus_bmi >= 18.5 and rumus_bmi < 22.9):
    print("berat badan ideal")
elif(rumus_bmi >= 23 and rumus_bmi < 29.9):
    print("berat badan berlebih dan berpotensi obesitas")
elif(rumus_bmi >= 30):
    print("obesitas")

print("rumus bmi dari berat badan dibagi tinggi")
print("hasil bmi dari berat badan" , berat_badan, "tinggi" , tinggi, "adalah" , rumus_bmi)