# SOAL WAJIB
# SOAL NO 2, 3, 4, 6, 7, 18, 19

# SOAL WAJIB NO 2
# PERSAMAAN LINIER 1 VARIABEL
#---> def  adalah sebuah functiion atau kata kunci dalam bahasa pemograman yang digunakan untuk mendefinisikan seuah kode
def persamaanlinear1(a, b):
    if a == 0:
        print("persamaan ini tidak memiliki solusi")
    elif b == 0:
        print("persamaan ini tidak memiliki solusi")
    else:
        x = -b / a
        print("print solusi dari persamaan adalah x = ", x)
#f cara yang efisien dan ekspresif untuk memformat string dalam bahasa pemrograman
#(...) merupakan parameter nilai atau variabel yang dapat diberikan kepada fungsi sebuah input opsional
# SOAL WAJIB NO 3
# LISTRIK, MAGNET, SUMBER ENERGI (RANGKAIAN RESISTOR PARAREL SERI)
def hitung_rs(resistor):
    rtotal = 0
    for R in resistor:
        rtotal += R
    return rtotal
# return  adalah kata kunci yang digunakan untuk mengembalikan hasil atau nilai dari fungsi (opsional)
# SOAL WAJIB NO 4
# LISTRIK, MAGNET, DAN SUMBER ENERGI
# SOAL WAJIB NO 6
# SUHU KALOR PERMUAIAN

# SOAL WAJIB NO 7
# SUHU KALOR PEMUAIAN (PERUBAHAN ENERGI PANAS)
def perubahan(m, c, Tawal, Takhir):
    Q = (m * c * (Tawal - Takhir))
    print(Q)

# SOAL WAJIB NO 18
# TEOREMA PHYTAGORAS 
def cek_sudut(pilihan):
    sudut = int(input("Masukkan sudut dari C: "))
    
    if sudut == 90:
        print(f"Sudut C ke {pilihan} adalah siku-siku")
    elif 0 <= sudut < 90:
        print(f"Sudut dari C ke {pilihan} adalah lancip")
    elif 90 < sudut <= 180:
        print(f"Sudut dari C ke {pilihan} adalah tumpul")
    else:
        print("Masukkan sudut antara 0 dan 180 derajat")

# SOAL WAJIB 19
# RELASI DAN FUNGSI

# SOAL TIDAK WAJIB 9
# USAHA ENERGI & PESAWAT SEDERHANA
def energi_potensial(m, g, h):
    energi_potensial = m * g * h
    print("energi potensial yang dihasilakan brnda tersebut adalah", energi_potensial)

def energi_mekanik(m, g, h,v):
    energi_mekanik = (m * g * h) + (0.5 * m *(v* 2))
    print("energi mekanik yang dihasilkan benda tersebut adalah", energi_mekanik)

# SOAL TIDAK WAJIB NO 10
# GAYA, GERAK, USAHA ENERGI, DAN PESAWAT SEDERHANA
def gaya(m, a):
    perkalian = (m * a)
    print(perkalian)


def kecepatan(f, s):
    perkalian = f / s
    print(perkalian)


# SOAL TIDAK WAJIB NO 11
# LISTRIK, MAGNET, DAN SUMBER ENERGI
def massajenis(m, v):
    pembagian = m / v
    print(pembagian)

def kecepatan(s, t):
    pembagian = s / t
    print(pembagian)

# SOAL TIDAK WAJIB 14
# SUHU, KALOR, PEMUAIAN KONVERSI SUHU (REAMUR, CELCIUS, KELVIN, FAHRENHEIT
def konversisuhu(suhu, dari1, ke2):
    if dari1 == "C" and ke2 == "F" :
        hasil = (suhu * 9/5) + 32
    elif dari1 == "C" and ke2 == "K" :
        hasil = suhu + 273.15
    elif dari1 == "C" and ke2 == "R" :
        hasil = suhu * 4/5
    elif dari1 == "C" and ke2 == "Ra" :
        hasil = (suhu + 273.15) * 9/5
    else:
        hasil = "konversi tidak valid"
    return hasil

# SOAL TIDAK WAJIB NO 17
# TEOREMA PYTHAGORAS
def c(a, b):
    c = (a**2 + b**2)
    print("hasil perhitungan adalah", c)




# while true adalah jenis loop yang akan terus berjalan tanpa henti selama kondisi yang diberikan selalu bernilai true
# print adalah sebuah fungsi dalam bahasa pemrograman python untuk menampilkan teks atau nilai nilai ke layar atau output
while True:
    print("\n")
    print("[]:::::::::::::::PEMILIHAN TEMA SOAL:::::::::::::::[]")
    print("~~~~~SILAHKAN PILIH TEMA~~~~~")
    print("\n")
    print("1.PERSAMAAN LINEAR 1 VARIABEL")
    print("2.LISTRIK, MAGNET, SUMBER ENERGI RANGKAIAN RESISTOR PARALEL DAN SERI")
    print("3.GAYA COLOUMB")
    print("4.SUHU KALOR PEMUAIAN")
    print("5.PERUBAHAN ENERGI PANAS")
    print("6.TEOREMA PYTHAGORAS MENENTUKAN SUDUT")
    print("7.RELASI DAN FUNGSI MENCARI BILANGAN GANJIL DARI SUATU HIMPUNAN")
    print("8.USAHA ENERGI & PESAWAT SEDERHANA")
    print("9.GAYA, GERAK, USAHA ENERGI, DAN PESAWAT SEDERHANA")
    print("10.LISTRIK, MAGNET, DAN SUMBER ENERGI")
    print("11.SUHU, KALOR, PEMUAIAN KONVERSI SUHU (REAMUR, CELCIUS, KELVIN, FAHRENHEIT")
    print("12.TEOREMA PYTHAGORAS MENGHITUNG C")
    print("\n")
    pilihan = float(input("Masukkan pilihan anda = "))
# if adalah sebuah kata kunci yangn digunakan untuk mengimplementasi struktur kontrol percabangan atau kondisional, fungsi if juga untuk menguji apakah suatu kondisi atau ekspresi bernilai true atau false
    if (pilihan == 1):
        print("\n")
        print(">>>>>>>>>PERSAMAAN LINEAR 1 VARIABEL<<<<<<<<<<")
        print("Silahkan pilih soal")
        print("1.PERSAMAAN LINEAR 1 VARIABEL")
        pilih = float(input("Masukkan pilihan soal = "))

        if (pilih == 1):
            a = float(input("masukkan koofisien a: "))
            b = float(input("masukkan koofisien b: "))

            persamaanlinear1(a, b)

    elif (pilihan == 2): #elif ---> elif adalah singkatan dari else if adalah bagian dari struktur kontrol percabangan dalam bahasa pemrograman python
        print("\n")
        print(">>>>>>>>>RANGKAIAN RESISTOR SERI DAN PARALEL<<<<<<<<<<")
        print("Silahkan pilih soal")
        print("1.RANGKAIAN SERI")
        print("2.RANGKAIAN PARALEL")
        pilih = float(input("Masukkan pilihan soal = "))
        #float dalah tipe data dalam pemrograman yang digunakan untuk merepresentasikan bilangan desimal atau bilangan pecahan
        if (pilih == 1):
            r = float(input("Masukkan jumlah resistor : "))
            resistor = [float(input("Masukkan nilai resistor ke-" + str(i+1)+" (ohm):")) for i in range(r)]
            hitung_rs(resistor)
            rs = hitung_rs(resistor)
            print("Resistansi total untuk rangkaian seri :", rs, "ohm")
            
        elif (pilih == 2):
            def hambatan_paralel(resistors):
                total_hambatan = sum(1 / resistor for resistor in resistors if resistor > 0)
                #sum adalah sebuah fungsi atau operasi yang digunakan untuk menjumlahkan semua elemen dalam sebuah iterable
                if total_hambatan == 0:
                    return "Hambatan total tidak dapat dihitung karena ada resistor dengan nilai 0 atau negatif."
                ## return  adalah kata kunci yang digunakan untuk mengembalikan hasil atau nilai dari fungsi (opsional) 
                hambatan_paralel = 1 / total_hambatan
                return hambatan_paralel
            
            jumlah_resistor = int(input("Masukkan jumlah resistor: "))
            resistor_values = []
                
            for i in range (jumlah_resistor):
                nilai_resistor = float(input(f"Masukkan nilai resistor ke-{i + 1} (ohm): "))
                resistor_values.append(nilai_resistor)
            #append    
            total_hambatan = hambatan_paralel(resistor_values)
            print("Hambatan total dari rangkaian paralel adalah:", total_hambatan, "ohm")
             
    elif (pilihan == 3) :
        print("\n")
        print(">>>>>>>>>GAYA COLOUMB<<<<<<<<<<")
        print("Silahkan pilih soal")
        print("1.GAYA COLOUMB")
        pilih = float(input("Masukkan pilihan soal = "))
    
        if (pilih == 1) :
            k = int(input("masukkan k ="))
            q1 = int(input("masukkan q1 ="))
            q2 = int(input("masukkan q2 ="))
            r = int(input("masukkan r ="))
            F = k * (q1 * q2) / r ** 2
            print (F)
        
    elif (pilihan == 4):
        print("\n")
        print(">>>>>>>>>SUHU KALOR DAN PEMUAIAN<<<<<<<<<<")
        print("Silahkan pilih soal")
        print("1.SUHU KALOR DAN PEMUAIAN")
        pilih = float(input("Masukkan pilihan soal = "))

        if pilih == 1 :
            m = int(input("masukkan m = "))
            v = int(input("masukkan v ="))
            Q = 0.5 * m * v**2
            print("hasil perubahan adalah", Q)

    elif (pilihan == 5):
        print("\n")
        print(">>>>>>>>>PERUBAHAN ENERGI PANAS<<<<<<<<<<")
        print("Silahkan pilih soal")
        print("1.PERUBAHAN ENERGI PANAS")
        pilih = float(input("Masukkan pilihan soal = "))

        if (pilih == 1):
            m = float(input("masukkan massa benda (gram): "))
            c = float(input("masukkan kalor jenis(j/g'C): "))
            Tawal = float(input("masukkan suhu awal(C): "))
            Takhir = float(input("masukkan suhu akhir (C): "))
            perubahan(m, c, Tawal, Takhir)

    elif (pilihan == 6):
        print("\n")
        print(">>>>>>>>>TEOREMA PYTHAGORAS<<<<<<<<<<")
        print("Silahkan pilih soal")
        print("1.C SUDUT KE A")
        print("2.C SUDUT KE B")
        pilih = float(input("Masukkan pilihan soal = "))

        if pilih == 1:
            cek_sudut("A")
        elif pilih == 2:
            cek_sudut("B")
        else:
            print("Pilihan tidak valid. Pilih 1 untuk A atau 2 untuk B")
                
    elif (pilihan == 7):
        print("MENCARI BILANGAN GANJIL DALAM SUATU HIMPUNAN")
        input_himpunan = input("Masukkan himpunan angka (pisahkan dengan spasi): ")
        himpunan = [int(x) for x in input_himpunan.split()] #fungsi split adalah untuk memisahkan sebuah string menjadi beberpa bagian berdasarkan pemisah tertentu
        print("Sebelum dicari bilangan ganjil =", himpunan)
        himpunan.sort() #fungsi sort digunakan untuk mengurutkan elemen elemen dalam sebuah list(daftar) 
        ganjil = [i for i in himpunan if i % 2 != 0]
        print("Bilangan ganjil dalam himpunan adalah", ganjil)
# for dalam bahasa pemograman digunakan untuk mengulangi serangkaian pernyataan atau blok kode berulang kali               
    elif (pilihan == 8):
        print("\n")
        print(">>>>>>>>>USAHA ENERGI DAN PESAWAT SEDERHANA<<<<<<<<<<")
        print("Silahkan pilih soal")
        print("1. ENERGI POTENSIAL")
        print("2. ENERGI MEKANIK")
        pilih = float(input("Masukkan pilihan soal = "))
        
        if (pilih == 1):
            m = int(input("masukan angka 1 :"))
            h = int(input("masukan angka 3 :"))
            v = int(input("masukan angka 4 :"))
            g = 9.8
            energi_potensial(m, g, h)
            
        elif (pilih == 2):
            m = int(input("masukan angka 1 :"))
            h = int(input("masukan angka 3 :"))
            v = int(input("masukan angka 4 :"))
            g = 9.8
            energi_mekanik(m, g, h,v)
            
    elif (pilihan == 9):
        print("\n")
        print(">>>>>>>>>GAYA GERAK ENERGI DAN USAHA PESAWAT SEDERHANA<<<<<<<<<<")
        print("Silahkan pilih soal")
        print("1. GAYA")
        print("2. KECEPATAN")
        pilih = float(input("Masukkan pilihan soal = "))
        
        if (pilih == 1):
            m = float(input("masukkan massa benda (kg) = "))
            a = float(input("masukkan percepat (m/s2) = "))
            gaya(m, a)
            
        elif (pilih == 2):
            f = float(input("masukkan f = "))
            s = float(input("masukkan s = "))
            kecepatan(f, s)
            
    elif (pilihan == 10):
        print("\n")
        print(">>>>>>>>>LISTRIK MAGNET DAN SUMBER ENERGI<<<<<<<<<<")
        print("Silahkan pilih soal")
        print("1. GAYA")
        print("2. KECEPATAN")
        pilih = float(input("Masukkan pilihan soal = "))
        
        if (pilih == 1):
            m = float(input("masukkan massa benda = "))
            v = float(input("masukkan volume = "))
            massajenis(m, v)
            
        elif (pilih == 2):
            s = float(input("masukkan jarak = "))
            t = float(input("masukkan waktu = "))
            kecepatan(s, t)
            
    elif (pilihan == 11):
          print("\n")
          print("                  KONVERSI SUHU                    ")
          print(" 1. Celcius")
          print(" 2. Kelvin")
          print(" 3. Reamur")
          print(" 4. Fahrenheit")
          pilihan = input(" Pilih 1,2,3,4 = ")
          
          print(" ")
          if pilihan == ("1"):
               print(" DIJADIKAN KE              ")
               print(" 1.Kelvin")
               print(" 2.Reamur")
               print(" 3.Fahrenheit")
               pilihan = input(" pilih 1,2,3 = ")

               if pilihan == ("1"):
                    suhu_celcius = int(input(" Masukkan suhu celcius = "))
                    kelvin = suhu_celcius + 273.15
                    print(" Suhu Celcius dari" , suhu_celcius , "ke Kelvin adalah" , kelvin )

               elif pilihan == ("2"):
                    suhu_celcius = int(input(" Masukkan Suhu Celcius = "))
                    reamur = suhu_celcius * 4/5
                    print(" Suhu Celcius dari" , suhu_celcius , "ke Reamur adalah" , reamur)

               elif pilihan == ("3"):
                    suhu_celcius = int(input(" Masukkan Suhu Celcius = "))
                    fahrenheit = suhu_celcius * 9/5 + 32
                    print(" Suhu Celcius dari" , suhu_celcius , "ke fahrenheit adalah", fahrenheit)

          elif pilihan == ("2"):
               print(" DIJADIKAN KE              ")
               print(" 1.Celcius")
               print(" 2.Reamur")
               print(" 3.Fahrenheit")
               pilihan = input(" Pilih 1,2,3 = ")


               if pilihan == ("1"):
                    suhu_kelvin = int(input(" Masukkan suhu kelvin = "))
                    Celcius = suhu_kelvin - 273.15
                    print(" Suhu Kelvin dari" , suhu_kelvin , "ke Celcius adalah" , Celcius)
                    
               elif pilihan == ("2"):
                    suhu_kelvin = int(input(" Masukkan Suhu Kelvin = "))
                    Reamur = (suhu_kelvin - 273) * 4/5
                    print(" Suhu Kelvin dari" , suhu_kelvin , "ke Reamur adalah" , Reamur)

               elif pilihan == ("3"):
                    suhu_kelvin = int(input(" Masukkan Suhu Kelvin = "))
                    Fahrenheit =(suhu_kelvin * 9/5) - 459.67
                    print(" Suhu Kelvin dari" , suhu_kelvin , "ke Reamur adalah" , Fahrenheit)
          
          elif pilihan == ("3"):
               print(" DIJADIKAN KE              ")
               print(" 1.Celcius")
               print(" 2.Kelvin")
               print(" 3.Fahrenheit")
               pilihan = input(" Pilih 1,2,3 = ")

               if pilihan == ("1"):
                    suhu_reamur = int(input(" Masukkan Suhu Reamur = "))
                    Celcius = 5/4 * suhu_reamur
                    print(" Suhu Reamur dari" , suhu_reamur , "dijadikan ke Celcius adalah" , Celcius)

               elif pilihan == ("2"):
                    suhu_reamur = int(input(" Masukkan Suhu Reamur = "))
                    Kelvin = (5/4 * suhu_reamur) + 273
                    print(" Suhu Reamur dari" , suhu_reamur , 'dijadikan ke Kelvin adalah' , Kelvin)

               elif pilihan == ("3"):
                    suhu_reamur = int(input(" Masukkan Suhu Reamur = "))
                    Fahrenheit = (suhu_reamur * 9/4) + 32
                    print(" Suhu Reamur dari" , suhu_reamur , 'dijadikan ke Fahrenheit adalah' , Fahrenheit)

          elif pilihan == ("4"):
               print(" DIJADIKAN KE              ")
               print(" 1.Celcius")
               print(" 2.Kelvin")
               print(" 3.Reamur")
               pilihan = input(" Pilih 1,2,3 = ")

               if pilihan == ("2"):
                    suhu_fahrenheit = int(input(" Masukkan Suhu Fahrenheit = "))
                    Kelvin = (suhu_fahrenheit + 459.67) * 5/9
                    print(" Suhu Fahrenheit dari" , suhu_fahrenheit , 'ke Kelvin adalah' , Kelvin)


               elif pilihan == ("3"):
                    suhu_fahrenheit = int(input(" Masukkan Suhu Fahrenheit = "))
                    Reamur = 4/9 * (suhu_fahrenheit - 32)
                    print(" Suhu Fahrenheit dari" ,suhu_fahrenheit , 'ke Reamur adalah' , Reamur)
            
    elif (pilihan == 12):
        print("\n")
        print(">>>>>>>>>TEOREMA PYTHAGORAS<<<<<<<<<<")
        print("Silahkan pilih soal")
        print("1. MENGHITUNG C")
        pilih = float(input("Masukkan pilihan soal = "))
        
        if (pilih == 1):
            a = float(input("masukkan nilai a ="))
            b = float(input("masukkan nilai b ="))
            c(a, b)
            
        
        
            
            
            
                               
                
            