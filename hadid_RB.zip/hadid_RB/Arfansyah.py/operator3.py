# operator
# contoh
# penjumlahan dari 2 dengan 3

print(2 + 3)

# 1. penjumlahan antara 8 dan -3
# 2. pengurangan antara -10 dan -5
# 3. perkalian antara -2 dengan 7
# 4. prmbagian antara 19 dengan 5
# 5. pembagian bulat antara 75 dengan 13
# 6. sisa hasil bagi antara 108 dengan 15
# operator
# contoh 
# penjumlahan antara 8 dan -1

print(8 + -3)
print(-10 - -5)
print(-2 * 7)
print(19 / 5)
print(75 // 13)
print(108 % 15)