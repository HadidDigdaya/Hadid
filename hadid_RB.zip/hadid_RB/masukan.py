kata="ganteng"
kata=input("masukkan kata kata=")
print(kata)

#input adalah suatu fungsi yang mengembalikan nilai
#nilai yang dikembalikan berupa kata/kalimat
angka1=input("masukkan angka 1=")
angka2=input("masukkan angka 2=")

print( int(angka1) + int(angka2))


