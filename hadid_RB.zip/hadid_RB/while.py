#while dan for itu sama sama untuk perulangan 
#bedanya while harus ditambahkan kondisi
#== sama dengan
#!= tidak sama dengan
#while=kapan/tidak pasti jumlahnya
#for=untuk/pasti jumlahnya

ulangi="tidak"

while (ulangi == "tidak"):
    print("apakah jarot ganteng?")

    jawaban=input ("(ya/tidak)")

#aloritma perulangan while
ganteng ="tidak"

while (ganteng !='ya'):
     ganteng=input("apakah saya ganteng? (ya/tidak):")

print("terimakasih anda telah jujur mengatakan saya ganteng")

