#Listrik, magnet, dan sumber energi
def resistor():
        

        n = int(input("Masukkan jumlah resistor: "))

        resistors = []
        for i in range(n):
            r = float(input(f"Masukkan nilai resistor {i+1} (ohm): "))
            resistors.append(r)

        # Input pilihan hitungan
        print("Pilih operasi:")
        print("1. Paralel")
        print("2. Seri")

        pilih = input("Pilih (1/2): ")

        # Eksekusi operasi
        if pilih == "1":
            rt = 0
            for r in resistors:
                rt += 1/r
            rt = 1/rt
            print(f"Resistansi total secara paralel: {rt} ohm")
        elif pilih == "2":
            rt = 0
            for r in resistors:
                rt += r
            print(f"Resistansi total secara seri: {rt} ohm")
        else:
            print("Pilihan tidak valid!")

    # Panggil fungsi resistor
resistor()






