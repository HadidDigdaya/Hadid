ganteng ="tidak"

while (ganteng !='ya'):
     ganteng=input("apakah saya ganteng? (ya/tidak):")

print("terimakasih anda telah jujur mengatakan saya ganteng")
