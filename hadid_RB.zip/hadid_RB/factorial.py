def factor(bill):
    n=1
    if bill== 0:
        return n
    else:
        for i in range(bill)
             n*=i+1
        return n

print(factor(3))
print(factor(5))
print(factor(10))

