def addition(x,y):
    return x+y

print(addition(2,3))

def convert(minutes,second):
    return minutes*second

print(convert(5,60))

def convert(x):
    return x*60

print(convert(3))