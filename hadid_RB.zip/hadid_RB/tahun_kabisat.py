def isKabisat(tahun):
    if(tahun % 4==0 and tahun %100 !=0) or (tahun % 400==0):
        return "kabisat"
    else:
        return"bukan tahun kabisat"
print(isKabisat(1900))
print(isKabisat(2014))

