def gaya_coulomb(q1,q2,r):
    f = k * (q1 * q2) / ( r ** 2)
    return f

q1 = int(input("masukkan nilai q1 (coulomb):"))
q2 = int(input("masukkan nilai q2 (coulomb):"))
r = int(input("masukkan jarak r (coulomb):"))
k = 8.99 * 10 ** 9

print(f"gaya coulomb antara muatan {q1} c dan {q2} c dengan jarak {r} meter adalah {gaya_coulomb(q1,q2,r)}newton.")

